
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { NewsletterDisplay } from './components/NewsletterDisplay';
import { LoadingIndicator } from './components/LoadingIndicator';
import { ErrorMessage } from './components/ErrorMessage';
// SourceList is no longer imported
import { fetchNewsletterContent } from './services/geminiService';
// GroundingSource type is no longer needed here
import { NEWSLETTER_PROMPT } from './constants';

const App: React.FC = () => {
  const [newsletterMarkdown, setNewsletterMarkdown] = useState<string | null>(null);
  // groundingSources state removed
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKeyMissing, setApiKeyMissing] = useState<boolean>(false);

  const handleGenerateNewsletter = useCallback(async () => {
    if (!process.env.API_KEY) {
      setError("API_KEY environment variable is not set. Please configure it to use the AI features.");
      setApiKeyMissing(true);
      setIsLoading(false);
      return;
    }
    setApiKeyMissing(false);
    setIsLoading(true);
    setError(null);
    setNewsletterMarkdown(null);
    // setGroundingSources removed

    try {
      const result = await fetchNewsletterContent(NEWSLETTER_PROMPT);
      setNewsletterMarkdown(result.text);
      // setGroundingSources removed
    } catch (e) {
      console.error(e);
      if (e instanceof Error) {
        setError(`Failed to generate newsletter: ${e.message}`);
      } else {
        setError('An unknown error occurred while generating the newsletter.');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  // Check for API_KEY on initial mount
  React.useEffect(() => {
    if (!process.env.API_KEY) {
      setError("Welcome! To generate newsletters, the API_KEY environment variable must be configured.");
      setApiKeyMissing(true);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900 text-slate-100">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="bg-slate-800 shadow-2xl rounded-lg p-6 md:p-10 max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-sky-400 mb-2">Your Weekly Tax & SMSF Update</h2>
            <p className="text-slate-400">Stay informed with AI-powered insights into Australian Taxation and Self-Managed Super Funds.</p>
          </div>

          <div className="mb-8 text-center">
            <button
              onClick={handleGenerateNewsletter}
              disabled={isLoading || apiKeyMissing}
              className={`px-8 py-3 font-semibold rounded-lg shadow-md transition-all duration-300 ease-in-out
                ${apiKeyMissing 
                  ? 'bg-gray-500 text-gray-300 cursor-not-allowed' 
                  : isLoading 
                    ? 'bg-sky-700 text-sky-300 cursor-not-allowed animate-pulse' 
                    : 'bg-sky-500 hover:bg-sky-600 text-white focus:ring-4 focus:ring-sky-300 transform hover:scale-105'
                }`}
            >
              {isLoading ? 'Generating Newsletter...' : 'Generate Latest Newsletter'}
            </button>
          </div>

          {error && <ErrorMessage message={error} />}
          {isLoading && <LoadingIndicator />}

          {!isLoading && newsletterMarkdown && (
            <div className="mt-8">
              <NewsletterDisplay markdownContent={newsletterMarkdown} />
              {/* SourceList component rendering removed */}
            </div>
          )}
           {!isLoading && !error && !newsletterMarkdown && !apiKeyMissing && (
            <div className="text-center py-10 text-slate-400">
              <p className="text-lg">Click the button above to generate your newsletter.</p>
              <p className="mt-2 text-sm">Content is generated live using AI for the latest information.</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;