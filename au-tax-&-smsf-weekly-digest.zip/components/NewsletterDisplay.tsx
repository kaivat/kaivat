
import React from 'react';
import ReactMarkdown, { Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  LegislativeIcon,
  ATORulingsIcon,
  SMSFIcon,
  MarketTrendsIcon,
  TipsRemindersIcon,
  DefaultNewsletterIcon,
  getNodeText
} from './IconComponents';
import { SECTION_ICON_MAPPING, IconKey } from '../constants';

interface NewsletterDisplayProps {
  markdownContent: string;
}

const iconComponentsMap: Record<IconKey, React.ElementType> = {
  'Key Legislative Changes': LegislativeIcon,
  'ATO Rulings and Guidance': ATORulingsIcon,
  'SMSF Specific News': SMSFIcon,
  'Market Trends & Economic Impacts': MarketTrendsIcon,
  'Tips and Reminders': TipsRemindersIcon,
  'Default': DefaultNewsletterIcon,
};

const getIconForSection = (sectionTitle: string): React.ElementType => {
  for (const key in SECTION_ICON_MAPPING) {
    if (sectionTitle.toLowerCase().includes(key.toLowerCase())) {
      return iconComponentsMap[SECTION_ICON_MAPPING[key]];
    }
  }
  return iconComponentsMap['Default'];
};


export const NewsletterDisplay: React.FC<NewsletterDisplayProps> = ({ markdownContent }) => {

  const customComponents: Components = {
    h2: ({ node, children, ...props }) => {
      const headingText = getNodeText(children);
      const IconComponent = getIconForSection(headingText);
      
      // Apply original prose styles for h2, then add flex for icon alignment
      // The class names are from index.html's .prose h2 definition
      return (
        <h2 
          {...props} 
          className="text-2xl font-bold mt-10 mb-4 text-slate-800 flex items-center"
          id={headingText.toLowerCase().replace(/\s+/g, '-')} // Add id for potential deep linking
        >
          <IconComponent className="w-7 h-7 mr-3 text-sky-600 flex-shrink-0" />
          {children}
        </h2>
      );
    },
     h1: ({ node, children, ...props }) => {
        const headingText = getNodeText(children);
        // The class names are from index.html's .prose h1 definition
        return (
            <h1 
            {...props} 
            className="text-4xl font-extrabold mb-6 text-slate-900 border-b-2 border-sky-500 pb-3 flex items-center"
            id={headingText.toLowerCase().replace(/\s+/g, '-')}
            >
            <DefaultNewsletterIcon className="w-9 h-9 mr-4 text-sky-500 flex-shrink-0" />
            {children}
            </h1>
        );
    }
  };

  return (
    <div className="prose prose-sm sm:prose-base lg:prose-lg xl:prose-xl max-w-none bg-white p-6 sm:p-8 rounded-lg shadow-xl text-slate-800">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={customComponents}>
        {markdownContent}
      </ReactMarkdown>
    </div>
  );
};
