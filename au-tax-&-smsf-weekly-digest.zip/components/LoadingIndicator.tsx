
import React from 'react';

export const LoadingIndicator: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-10">
      <div className="w-16 h-16 border-4 border-sky-500 border-t-transparent rounded-full animate-spin mb-4"></div>
      <p className="text-sky-300 text-lg font-semibold">Generating your newsletter...</p>
      <p className="text-slate-400 text-sm">This may take a moment as we gather the latest information.</p>
    </div>
  );
};
