
export const NEWSLETTER_PROMPT = `You are an AI assistant tasked with creating a weekly newsletter on Australian Taxation and Self-Managed Super Funds (SMSF).
Generate a detailed and easy-to-understand newsletter for the current week (assume today is the date of generation), covering:
1.  **Key Legislative Changes:** Any new laws, regulations, or proposed changes related to Australian tax or SMSFs.
2.  **ATO Rulings and Guidance:** Important announcements, tax rulings (TRs), practical compliance guidelines (PCGs), or other key communications from the Australian Taxation Office.
3.  **SMSF Specific News:** Updates relevant to trustees of Self-Managed Super Funds, including investment rules, compliance obligations, audit requirements, and strategic considerations.
4.  **Market Trends & Economic Impacts:** Briefly touch upon how broader economic factors or significant market trends might be influencing Australian tax and superannuation landscape.
5.  **Tips and Reminders:** Actionable advice, important upcoming deadlines (e.g., for tax returns, BAS, super contributions), or common pitfalls to avoid for individuals and businesses.

The newsletter should be well-structured with clear Markdown headings for each section (e.g., # Main Title, ## Section Title, ### Subsection Title).
Use Markdown for formatting (e.g., *italic*, **bold**, - bullet points for lists, > for blockquotes).
Ensure the language is accessible and easily understandable by a general audience, not just tax professionals. Avoid overly technical jargon where possible, or explain it briefly.
Include practical insights or implications for taxpayers or SMSF trustees where appropriate.
Use Google Search grounding to ensure the information is current, accurate, and reflects the latest developments.
Begin the newsletter with a title like "# Australian Tax & SMSF Weekly Digest - [Current Date]". Make sure to replace [Current Date] with the actual current date in 'Month Day, Year' format.
Conclude with a brief, friendly closing statement.
Do not invent information; rely on the search results for factual content. If no significant news is found for a section, state that briefly.
`;

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export type IconKey = 
  | 'Key Legislative Changes'
  | 'ATO Rulings and Guidance'
  | 'SMSF Specific News'
  | 'Market Trends & Economic Impacts'
  | 'Tips and Reminders'
  | 'Default';

export const SECTION_ICON_MAPPING: Record<string, IconKey> = {
  "Key Legislative Changes": "Key Legislative Changes",
  "ATO Rulings and Guidance": "ATO Rulings and Guidance",
  "SMSF Specific News": "SMSF Specific News",
  "Market Trends & Economic Impacts": "Market Trends & Economic Impacts",
  "Tips and Reminders": "Tips and Reminders",
};
