
export interface NewsletterData {
  text: string;
}