
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { NewsletterData } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

const getApiKey = (): string => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY environment variable is not set.");
    throw new Error("API_KEY environment variable is not set. Please configure it to use the AI features.");
  }
  return apiKey;
};


export const fetchNewsletterContent = async (prompt: string): Promise<NewsletterData> => {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        // No responseMimeType: "application/json" when using googleSearch
      },
    });

    const text = response.text;
    
    return { text };

  } catch (error) {
    console.error("Error fetching newsletter content from Gemini API:", error);
    if (error instanceof Error) {
        // Check for specific error messages related to API key issues if possible
        if (error.message.includes("API key not valid")) {
             throw new Error("Invalid API Key. Please check your API_KEY environment variable.");
        }
         throw new Error(`Gemini API request failed: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the Gemini API.");
  }
};